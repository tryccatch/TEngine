using System.Collections.Generic;
using System.IO;

namespace Qoder.Unity.Editor
{
	internal static class QoderDiscovery
	{
		public static IEnumerable<IQoderInstallation> GetInstallations()
		{
			foreach (var installation in QoderEditorInstallation.GetInstallations())
				yield return installation;
		}

		public static bool TryDiscoverInstallation(string editorPath, out IQoderInstallation installation)
		{
			try
			{
				if (QoderEditorInstallation.TryDiscoverInstallation(editorPath, out installation))
					return true;
			}
			catch (IOException)
			{
				installation = null;
			}

			return false;
		}
	}
}
