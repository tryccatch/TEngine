using System;

namespace Qoder.Unity.Editor
{
	internal enum GeneratorStyle
	{
		SDK = 1,
	}

	internal static class GeneratorFactory
	{
		private static readonly SdkStyleProjectGeneration _sdkStyleProjectGeneration = new SdkStyleProjectGeneration();

		public static IGenerator GetInstance(GeneratorStyle style)
		{
			return _sdkStyleProjectGeneration;
		}
	}
}
