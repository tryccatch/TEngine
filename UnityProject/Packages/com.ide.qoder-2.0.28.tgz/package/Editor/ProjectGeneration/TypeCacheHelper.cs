using SR = System.Reflection;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;

namespace Qoder.Unity.Editor
{
	internal class TypeCacheHelper
	{
		internal static IEnumerable<SR.MethodInfo> GetPostProcessorCallbacks(string name)
		{
			return TypeCache
				.GetTypesDerivedFrom<AssetPostprocessor>()
				.Select(t => t.GetMethod(name, SR.BindingFlags.Public | SR.BindingFlags.NonPublic | SR.BindingFlags.Static))
				.Where(m => m != null);
		}
	}
}
