using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Qoder.EditorTests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
