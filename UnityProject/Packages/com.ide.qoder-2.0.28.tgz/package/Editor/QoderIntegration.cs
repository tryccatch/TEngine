using UnityEditor;

namespace Qoder.Unity.Editor
{
	[InitializeOnLoad]
	internal static class QoderIntegration
	{
		public static string PackageVersion()
		{
			var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(QoderIntegration).Assembly);
			return package?.version ?? "1.0.0";
		}
	}
}
