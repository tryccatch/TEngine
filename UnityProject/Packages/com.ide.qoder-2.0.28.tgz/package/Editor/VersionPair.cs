using System;

namespace Qoder.Unity.Editor
{
	internal struct VersionPair
	{
		public Version IdeVersion;
		public Version LanguageVersion;

		public VersionPair(int ideMajor, int ideMinor, int languageMajor, int languageMinor)
		{
			IdeVersion = new Version(ideMajor, ideMinor);
			LanguageVersion = new Version(languageMajor, languageMinor);
		}
	}
}
